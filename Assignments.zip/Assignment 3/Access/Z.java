package Access;
import Access_specifiers.M;
import Access_specifiers.N;
import Access_specifiers.P;
public class Z {

	public static void main(String[] args) {
		X obj=new X();
		obj.printnumberX();
		M objM=new M();
		N objN=new N();
		P objP=new P();
		objM.printnumber();
		objN.printnumberN();
		objP.printnumberN();
		
		// TODO Auto-generated method stub

	}

}
