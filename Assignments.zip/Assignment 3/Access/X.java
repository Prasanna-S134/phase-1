package Access;

public class X {
private int a=10;
long b=4;
protected float c=6;
char s='d';
public void printnumberX(){
	System.out.println(" "+a+" "+b+" "+c+" "+s);
}
}
