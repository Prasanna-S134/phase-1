
public class ass1 {
	
	
	public static void main(String[] args) {
		String y= new String ("Mumbai");    
		String l= new String ("delhi");     
		String p = new String("Hello");  
		String t= "Delhi";    
		String o = "Mumbai"; 
		String k= "delhi";  
		if(o.equals(l))
			System.out.println("True o equals l");
		else
		System.out.println("False o equals l");
	if (o==l)
		System.out.println("True o == l");
	else
		System.out.println("False o == l");
	if(y.equals(p))
		System.out.println("True y equals p");
	else
	System.out.println("False y equals p");
	if (y==p)
		System.out.println("True y == p");
	else
		System.out.println("False y == p");
	if(t.equals(o))
		System.out.println("True t equals o");
	else
	System.out.println("False t equals o");
if (t==o)
	System.out.println("True t == o");
else
	System.out.println("False t == o");
if(k.equals(y))
	System.out.println("True k equals y");
else
System.out.println("False k equals y");
if (k==y)
System.out.println("True k == y");
else
System.out.println("False k == y");
if(o.equals(l))
	System.out.println("True o equals l");
else
System.out.println("False p equals y");
if (p==y)
System.out.println("True p == y");
else
System.out.println("False p == y");
	}
	
}