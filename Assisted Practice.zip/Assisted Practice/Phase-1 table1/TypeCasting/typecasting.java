package TypeCasting;

public class typecasting {

	public static void main(String[] args) {
		//Implicit TypeCasting
		byte a=10;
		short b=a;
		int c=b;
		float d=c;
		double e=d;
		System.out.println("Implicit TypeCasting : "+e);
		//Explicit TypeCasting
		double f=10.0;
		float g=(float) f;
		int h=(int) g;
		System.out.println("Explicit TypeCasting : "+h);

	}

}
