package Methods;
public class callbyvalue{
		 int n=100;

		 int Method(int n) 
		{
			n = n*10/50;
			return(n);
		}

		public static void main(String args[]) {
			callbyvalue obj = new callbyvalue();
			System.out.println("Before call by value : "+obj.n);
			obj.Method(20);
			System.out.println("After call by value : "+obj.n);
			}
		}

