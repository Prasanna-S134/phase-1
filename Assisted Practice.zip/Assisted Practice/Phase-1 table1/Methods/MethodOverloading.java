package Methods;

public class MethodOverloading {
		
		public void Shape(int a,int b)
		    {
		         System.out.println("Area of Rectangle: "+a*b);
		    }
		public void Shape(int r) 
		    {
		         System.out.println("Area of Circle : "+(3.14*r*r));
		    }

		    public static void main(String args[])
		   {

		    	MethodOverloading obj=new MethodOverloading();
		       obj.Shape(3,4);
		       obj.Shape(7);  
		   }
		}
