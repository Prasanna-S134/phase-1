package Access_specifiers;

public class N {
	private int k=9;
	long l=3;
	protected float m=5;
	public void printnumberN()
	{
		System.out.println(" "+k+" "+l+" "+m);
	}

}
