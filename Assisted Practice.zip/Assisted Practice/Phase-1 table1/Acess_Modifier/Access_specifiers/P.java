package Access_specifiers;

public class P extends N{
	public static void main (String args[])
	{
	N ob=new N();
	ob.printnumberN();
	M obj=new M();
	obj.printnumber();
	}

}
