package Access_specifiers;

public class M {
	private int a=10;
	long b=4;
	protected float c=8;
	public void printnumber()
	{
		System.out.println(" "+a+" "+b+" "+c);
	}
}
