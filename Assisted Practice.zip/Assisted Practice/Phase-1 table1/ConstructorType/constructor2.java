package ConstructorType;
//parameterized constructor
class ParCons{
	public ParCons(int a,int b) {
		System.out.println("area of rectangle : "+a*b);
	}
	
}
public class constructor2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParCons obj=new ParCons(5,5);
	}

}
