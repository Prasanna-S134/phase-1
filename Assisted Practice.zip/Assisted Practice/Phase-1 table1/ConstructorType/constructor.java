package ConstructorType;
//No Argument Constructor
class NoArgCons{
	public NoArgCons() {
		int a=5;
		int b=5;
		System.out.println("area of rectangle : "+a*b);
	}
	
}
public class constructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoArgCons obj=new NoArgCons();
	}

}
