package Runnable;

public class runnabel implements Runnable {  
	  
    @Override  
    public void run() {  
        System.out.println("Thread has ended");  
    }  
   
    public static void main(String[] args) {  
    	runnabel ex = new runnabel();  
        Thread t1= new Thread(ex);  
        t1.start();  
        System.out.println("Good morning,This is a runnable thread");  
    }  
} 

