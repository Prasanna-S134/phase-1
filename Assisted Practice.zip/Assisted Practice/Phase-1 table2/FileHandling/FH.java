package FileHandling;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class FH {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				char[] array = new char[60];
				Scanner sc= new Scanner(System.in);  
				System.out.println("\t\tFile Handling\n1.Reading the file\n2.Writing the file\n3.Appending the file");  
				  System.out.print("Enter Your choice: ");  
				  int ch = sc.nextInt(); 
				  switch (ch)
				  {
				  case 1:
				  {
					  try {
					      
					      FileReader input = new FileReader("E:/ss.txt");
					      input.read(array);
					      System.out.println("The file is READ and it contains:");
					      System.out.println(array);
					      input.close();
					    }
					    catch(Exception e) {
					      e.getStackTrace();
					    }
					  break;
				  }
				  case 2:
				  {
					  System.out.print("Enter a string to write: ");
					  Scanner sc1= new Scanner(System.in);  
					  String data= sc1.nextLine();       
					  //String data = "(Written) Good morning all";
					    
					    try {
					      FileWriter output = new FileWriter("E:/ss.txt");
					      output.write(data);
					      System.out.println("Data is written to the file.");
					      output.close();
					    }
					    catch (Exception e) {
					      e.getStackTrace();
					    }
					    break;
				  }
				  case 3:
				  {
					  System.out.print("Enter a string to Append: ");
					  Scanner sc2= new Scanner(System.in);  
					  String data= sc2.nextLine();     
					  try {
					         
					         File f1 = new File("E:/ss.txt");
					         if(!f1.exists()) {
					            f1.createNewFile();
					         }

					         FileWriter fileWritter = new FileWriter(f1,true);
					         BufferedWriter bw = new BufferedWriter(fileWritter);
					         bw.write(data);
					         bw.close();
					         System.out.println("Done");
					      } catch(IOException e){
					         e.printStackTrace();
					      }
				  }
				  }
			}
		
	}


